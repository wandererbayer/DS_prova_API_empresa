CREATE DATABASE provaDS1;
USE provaDS1;

CREATE TABLE funcionario
(
	id_func INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nome VARCHAR(20) NOT NULL,
    sobrenome VARCHAR(30) NOT NULL,
    fk_cargo INT, 
    FOREIGN KEY(fk_cargo) REFERENCES cargo(id_cargo)
);

CREATE TABLE cargo
(
	id_cargo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nome_cargo VARCHAR(40) NOT NULL,
	fk_departamento INT, 
	FOREIGN KEY(fk_departamento) REFERENCES departamento(id_dep)
);

CREATE TABLE departamento
(
	id_dep INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nome_departamento VARCHAR(40) NOT NULL
);

SELECT * FROM funcionario;

SELECT * FROM cargo;

SELECT * FROM departamento;